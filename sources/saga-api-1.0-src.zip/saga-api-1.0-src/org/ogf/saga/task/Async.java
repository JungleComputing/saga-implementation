package org.ogf.saga.task;

/**
 * This interface is empty on purpose, and is used only for tagging of SAGA
 * classes which implement the SAGA task model.
 */
public interface Async {
    // nothing here.
}
