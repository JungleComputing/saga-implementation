package org.ogf.saga.error;

import org.ogf.saga.SagaObject;

/**
 * This exception indicates that an operation failed semantically. This is the
 * least specific exception in SAGA.
 */
public class NoSuccessException extends SagaException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructs a NoSuccess exception.
     */
    public NoSuccessException() {
        super(NO_SUCCESS);
    }

    /**
     * Constructs a NoSuccess exception with the specified detail message.
     * 
     * @param message
     *            the detail message.
     */
    public NoSuccessException(String message) {
        super(NO_SUCCESS, message);
    }

    /**
     * Constructs a NoSuccess exception with the specified cause.
     * 
     * @param cause
     *            the cause.
     */
    public NoSuccessException(Throwable cause) {
        super(NO_SUCCESS, cause);
    }

    /**
     * Constructs a NoSuccess exception with the specified detail message and
     * cause.
     * 
     * @param message
     *            the detail message.
     * @param cause
     *            the cause.
     * 
     */
    public NoSuccessException(String message, Throwable cause) {
        super(NO_SUCCESS, message, cause);
    }

    /**
     * Constructs a NoSuccess exception with the specified detail message and
     * associated SAGA object.
     * 
     * @param message
     *            the detail message.
     * @param object
     *            the associated SAGA object.
     */
    public NoSuccessException(String message, SagaObject object) {
        super(NO_SUCCESS, message, object);
    }
}
